package game;
public enum KeyStatus {
    PRESSED,
    RELEASED;
}
